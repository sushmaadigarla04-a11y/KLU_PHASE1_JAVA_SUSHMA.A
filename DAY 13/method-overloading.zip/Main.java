import java.util.*;

class Main {

    // Method to add two numbers
    void add(int a, int b) {
        System.out.println("Addition of 2 numbers: " + (a + b));
    }

    // Method overloading - add three numbers
    void add(int a, int b, int c) {
        System.out.println("Addition of 3 numbers: " + (a + b + c));
    }

    public static void main(String[] args) {

        Scanner obj = new Scanner(System.in);

        int a, b, c;

        System.out.print("Enter first number: ");
        a = obj.nextInt();

        System.out.print("Enter second number: ");
        b = obj.nextInt();

        System.out.print("Enter third number: ");
        c = obj.nextInt();

        Main m = new Main();

        m.add(a, b);
        m.add(a, b, c);

        obj.close();
    }
}