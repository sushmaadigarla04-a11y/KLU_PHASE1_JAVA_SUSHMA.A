import java.util.*;

class Father
{
    void gen2()
    {
        System.out.println("gold");
    }
}

class Son extends Father
{
    void gen3()
    {
        System.out.println("cash");
    }
}

class Main
{
    public static void main(String args[])
    {
        Son obj = new Son();
        obj.gen3();
        obj.gen2();

        Father f = new Father();
        f.gen2();
    }
}