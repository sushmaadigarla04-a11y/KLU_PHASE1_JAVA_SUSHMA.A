class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head = null;
    Node tail = null;

    // Insert at the end
    public void insertEnd(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
            tail.next = head;
        } else {
            tail.next = newNode;
            tail = newNode;
            tail.next = head;
        }
    }

    // Insert at the beginning
    public void insertBeginning(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = tail = newNode;
            tail.next = head;
        } else {
            newNode.next = head;
            head = newNode;
            tail.next = head;
        }
    }

    // Delete a node by value
    public void delete(int key) {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        Node previous = tail;

        do {
            if (current.data == key) {

                // Only one node
                if (head == tail) {
                    head = tail = null;
                }
                // Delete head
                else if (current == head) {
                    head = head.next;
                    tail.next = head;
                }
                // Delete tail
                else if (current == tail) {
                    tail = previous;
                    tail.next = head;
                }
                // Delete middle node
                else {
                    previous.next = current.next;
                }

                System.out.println(key + " deleted.");
                return;
            }

            previous = current;
            current = current.next;

        } while (current != head);

        System.out.println("Element not found.");
    }

    // Display the list
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(Back to Head)");
    }
}

public class Main {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insertEnd(10);
        list.insertEnd(20);
        list.insertEnd(30);
        list.insertBeginning(5);

        System.out.println("Circular Linked List:");
        list.display();

        list.delete(20);

        System.out.println("After deletion:");
        list.display();
    }
}