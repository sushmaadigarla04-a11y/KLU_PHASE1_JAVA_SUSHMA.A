import java.util.*;
class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int col,row;
        for(row=0;row<n;row++,System.out.println())
        {
            for(col=0;col<=row;col++)
            System.out.print("*");
        }
        for(row=0;row<n;row++,System.out.println())
            for(col=0;col<n-row;col++)
                System.out.print("*");
    }
}