import java.util.*;
class Main 
{
    public static void main (String[] args) {
        LinkedList obj=new LinkedList();
        Scanner s=new Scanner(System.in);
        obj.add(s.nextInt());
        System.out.print(obj);
        int ind=s.nextInt();
        int val=s.nextInt();
        obj.add(ind,val);
        System.out.print(obj);
        int fele=s.nextInt();
        obj.addFirst(fele);
        System.out.print(obj);
        int lele=s.nextInt();
        obj.addLast(lele);
        System.out.print(obj);
        int getind=s.nextInt();
        System.out.println(obj.get(getind));
        System.out.println(obj.getFirst());
        System.out.println(obj.getLast());
        int indset=s.nextInt();
        int valset=s.nextInt();
        obj.set(indset,valset);
        System.out.println(obj);
        obj.remove();
        System.out.println(obj);
        obj.remove(2);
        System.out.println(obj);
        
        
    }
}