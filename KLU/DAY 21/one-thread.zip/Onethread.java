class Onethread extends Thread
{

     public void run()
    {
        System.out.print("thread is running");
    }
    
    public static void main (String[] args) {
        Onethread obj=new Onethread();
        System.out.println("threadd created");
        obj.start();
    }
}