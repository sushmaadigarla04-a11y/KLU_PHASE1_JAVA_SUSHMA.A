class Phonetask extends Thread
{
    String task;
    Phonetask(String tk)
    {
        this.task=tk;
    }
    public void run()
    {
        for(int i=1;i<=3;i++)
            System.out.println(task+" "+i);
    }
    public static void main (String[] args) {
        Phonetask t1=new Phonetask("playing music");
        Phonetask t2=new Phonetask("chatting");
        Phonetask t3=new Phonetask("download videos");
        t1.start();
        t2.start();
        t3.start();
    }
}