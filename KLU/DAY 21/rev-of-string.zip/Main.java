import java.util.*;

class Main 
{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine(); //cse
        Stack<Character> obj = new Stack<Character>();
        for (char ch : s.toCharArray()) //ch
            obj.push(ch); //c
        while (!obj.empty()) //
        {
            System.out.print(obj.pop()); //esc
        }
    }
}