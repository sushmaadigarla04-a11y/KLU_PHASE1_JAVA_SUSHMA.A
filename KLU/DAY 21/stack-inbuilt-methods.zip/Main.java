import java.util.*;

class Main 
{
    public static void main(String[] args) {
        Stack<Integer> obj = new Stack<>();
        Scanner s = new Scanner(System.in);

        obj.push(s.nextInt());
        obj.push(s.nextInt());
        System.out.println(obj);

        System.out.println(obj.peek());

        System.out.println(obj.pop());
        System.out.println(obj);

        System.out.println(obj.empty());

        System.out.println(obj.search(s.nextInt()));

        System.out.println(obj.size());

        obj.push(s.nextInt());
        System.out.println(obj);

        System.out.println(obj.firstElement());

        System.out.println(obj.lastElement());

        System.out.println(obj.get(0));

        obj.set(0, s.nextInt());
        System.out.println(obj);

        obj.add(s.nextInt());
        System.out.println(obj);

        obj.remove(0);
        System.out.println(obj);

        System.out.println(obj.contains(s.nextInt()));

        System.out.println(obj.indexOf(s.nextInt()));

        System.out.println(obj.isEmpty());

        obj.clear();
        System.out.println(obj);

        System.out.println(obj.isEmpty());
    }
}