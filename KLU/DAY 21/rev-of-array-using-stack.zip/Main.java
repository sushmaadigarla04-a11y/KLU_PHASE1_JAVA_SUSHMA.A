import java.util.*;

class Main
{
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        int arr[]=new int[n];
        for(int i=0;i<n;i++)
            arr[i]=sc.nextInt();
        Stack<Integer> obj=new Stack<Integer>();
        for(int i:arr)//ch
            obj.push(i);//c
        while(!obj.empty())//
        {
            System.out.print(obj.pop()+" ");//esc
        }
    }
}