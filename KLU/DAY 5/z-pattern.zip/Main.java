import java.util.*;
class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int row,col;
        for(row=0;row<n;row++,System.out.println())
        {
            for(col=0;col<n;col++)
            {
                if(row==0||row==n-1||row+col==n-1)
                System.out.print("*");
                else
                System.out.print(" ");
            }
        }
    }
}