
public class Main
{
	public static void main(String[] args) {
		if(!false){
		    System.out.print("ice");
		    System.out.print("cream");
		}else{
		    System.out.print("ice cream");
		}
		
	}
}
