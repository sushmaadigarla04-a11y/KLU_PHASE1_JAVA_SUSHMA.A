public class Main {
    public static void main(String[] args) {
        int a = 5;
        if(a==5){
            System.out.print(a+5);
        }
        else{
            System.out.print(a+4);
        }
    }
}