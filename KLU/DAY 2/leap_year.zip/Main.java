import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int y = scanner.nextInt();
        if (y % 400 == 0){
            System.out.println(y + " is a leap year.");
        }else if(y%100 == 0){
            System.out.println(y + " is not a leap year.");
        }else if(y%4 == 0){
            System.out.println(y + " is a leap year.");
        }
        else{
            System.out.println(y + " is not a leap year.");
        }
    }
}