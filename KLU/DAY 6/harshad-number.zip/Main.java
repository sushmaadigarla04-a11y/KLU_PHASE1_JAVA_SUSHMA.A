import java.util.*;
class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n=sc.nextInt();
        int temp=n;
        int sum=0,d;
        while(n!=0)
        {
            d=n%10;
            sum+=d;
            n=n/10;
        }
        if(temp%sum==0)
        System.out.print("Harshad Number");
        else
        System.out.print("Not a Harshad Number");
    }
}