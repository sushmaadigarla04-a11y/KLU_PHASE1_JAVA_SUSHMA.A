import java.util.*;
class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n1=sc.nextInt();
        int n2=sc.nextInt();
        int sum1=0,sum2=0,i;
        for(i=1;i<=n1/2;i++)
        {
            if(n1%i==0)
            sum1=sum1+i;
        }
        for(i=1;i<=n2/2;i++)
        {
            if(n2%i==0)
            sum2=sum2+i;
        }
        if(n1==sum2 && n2==sum1)
        System.out.print("Amicable Number");
        else
        System.out.print("Not an Amicable Number");
    }
}