import java.util.*;
class Main {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int d,ans =0;
        while(n!=0)
        {
            d=n%10;
            ans=ans+d;
            n=n/10;
        }
        System.out.print("Sum of digits " + ans);
    }
}