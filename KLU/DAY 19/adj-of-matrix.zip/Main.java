import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int V = obj.nextInt();
        int E = obj.nextInt();
        int[][] adj = new int[V][V];
        int[] deg = new int[V];
        for (int i = 0; i < E; i++) {
            int u = obj.nextInt();
            int v = obj.nextInt();
            adj[u][deg[u]++] = v;
            adj[v][deg[v]++] = u;
        }
        for (int i = 0; i < V; i++)
        {
            System.out.print(i + ": ");
            for (int j = 0; j < deg[i]; j++) {
                System.out.print(adj[i][j] + " ");
            }
            System.out.println();
        }
    }
}