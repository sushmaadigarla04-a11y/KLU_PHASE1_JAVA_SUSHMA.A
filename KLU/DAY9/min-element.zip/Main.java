import java.util.*;

class Main {

    class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    Node head = null;

    void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    void findMin() {
        if (head == null) {
            System.out.println("List is empty");
            return;
        }

        int min = head.data;
        Node temp = head;

        while (temp != null) {
            if (temp.data < min) {
                min = temp.data;
            }
            temp = temp.next;
        }

        System.out.println("Minimum element = " + min);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Main list = new Main(); 

        int n = sc.nextInt();

        while (n != -1) {
            list.insert(n);
            n = sc.nextInt();
        }

        list.findMin();
    }
}