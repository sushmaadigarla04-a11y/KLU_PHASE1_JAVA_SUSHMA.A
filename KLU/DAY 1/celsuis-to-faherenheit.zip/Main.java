import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		Float c = obj.nextFloat();
		Float f = (float)(c*9/5)+32;
		System.out.print(f);
	}
}
