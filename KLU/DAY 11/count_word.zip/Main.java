import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);

        String s = obj.nextLine();

        int space = 0;

        for (char c : s.toCharArray()) {
            if (c == ' ') {
                space++;
            }
        }

        System.out.println("Number of words = " + (space + 1));
    }
}