import java.util.*;
class Main {
    public static void main(String[] args) {
        int[] queue = new int[5];
        int front = 0;
        int rear = -1;

        
        queue[++rear] = 10;
        queue[++rear] = 20;
        queue[++rear] = 30;

       
        System.out.println("Queue:");
        for (int i = front; i <= rear; i++) {
            System.out.print(queue[i] + " ");
        }

        
        System.out.println("\nDeleted: " + queue[front++]);

        
        System.out.println("Front: " + queue[front]);
    }
}