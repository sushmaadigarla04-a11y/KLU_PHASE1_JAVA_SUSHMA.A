import java.util.*;
class Main {
    static void fun(int n)
    {
        if(n>0)
        {
            fun(n-1);
            System.out.print(n);
            System.out.println(n+1);
        }
    }
    public static void main(String args[]) {
        Scanner obj=new Scanner(System.in);
        int n=obj.nextInt();
        fun(n);
}}