class Vehicle {
    void displayVehicleType() {
        System.out.println("Vehicle Type");
    }
}

class Car extends Vehicle {
    void displayWheels() {
        System.out.println("Four Wheels");
    }
}

class Bike extends Vehicle {
    void displayWheels() {
        System.out.println("Two Wheels");
    }
}

class Auto extends Vehicle {
    void displayWheels() {
        System.out.println("Three Wheels");
    }
}

public class Main {
    public static void main(String[] args) {

        Car c = new Car();
        Bike b = new Bike();
        Auto a = new Auto();

        c.displayVehicleType();
        c.displayWheels();

        b.displayVehicleType();
        b.displayWheels();

        a.displayVehicleType();
        a.displayWheels();
    }
}