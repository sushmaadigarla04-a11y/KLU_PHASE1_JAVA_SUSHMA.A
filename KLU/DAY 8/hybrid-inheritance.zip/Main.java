import java.util.*;

class Grandfather
{
    void gen1()
    {
        System.out.println("Diamond");
    }
}

class Father extends Grandfather
{
    void gen2()
    {
        System.out.println("gold");
    }
}
class Mother extends Father
{
    void gen21()
    {
        System.out.println("copper");
    }
}
class Son extends Father
{
    void gen3()
    {
        System.out.println("cash");
    }
}
class Main
{
    public static void main(String args[])
    {
        Son s = new Son();
        s.gen3();
        s.gen2();
        s.gen1();
       Mother m= new Mother();
        m.gen21();
        m.gen2();
    }
}