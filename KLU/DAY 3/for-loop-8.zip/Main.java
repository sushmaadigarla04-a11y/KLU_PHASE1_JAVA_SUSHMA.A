import java.util.*;
class Main {
    public static void main(String args[]) {
        int i;
        for(i=2; i>3; i--)
        System.out.println(i);
    }
}