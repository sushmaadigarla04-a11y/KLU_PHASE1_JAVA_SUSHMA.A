import java.util.*;
class Main {
    public static void main(String args[]) {
        int i = 10;
        for(; i>0;i--)
        System.out.print(i +" ");
    }
}