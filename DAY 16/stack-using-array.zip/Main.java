import java.util.*;
class Main {
    public static void main(String[] args) {
        int[] stack = new int[5];
        int top = -1;

        
        stack[++top] = 10;
        stack[++top] = 20;
        stack[++top] = 30;

        
        System.out.println("Stack:");
        for (int i = top; i >= 0; i--) {
            System.out.print(stack[i] + " ");
        }

        
        System.out.println("\nPopped: " + stack[top--]);

        
        System.out.println("Top: " + stack[top]);
    }
}