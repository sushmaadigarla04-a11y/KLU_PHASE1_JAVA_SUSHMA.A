import java.util.*;

public class Main {
    static int[][] graph;
    static boolean[] visited;
    static int[] queue;
    static int front, rear;

    static void bfs(int start, int V) {
        visited[start] = true;
        queue[rear++] = start;
        while (front < rear) {
            int v = queue[front++];
            System.out.print(v + " ");
            for (int i = 0; i < V; i++) {
                if (graph[v][i] == 1 && !visited[i]) {
                    visited[i] = true;
                    queue[rear++] = i;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        int V = obj.nextInt();
        int E = obj.nextInt();
        graph = new int[V][V];
        visited = new boolean[V];
        queue = new int[V];
        front = rear = 0;
        for (int i = 0; i < E; i++) {
            int u = obj.nextInt();
            int v = obj.nextInt();
            graph[u][v] = 1;
            graph[v][u] = 1;
        }
        bfs(0, V);
        obj.close();
    }
}